
<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="col-xs-12 col-sm-7 col-md-8" style="background-color:#fff;top:20px;padding-top:10px" >
            <h3 style="color:#F00">Sorry! verification unsuccessfully
            </br> 
            Please try again </h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

