<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="row" style="background-color:#fff;top:20px;padding-top:10px" >
            <h3>Found Item List</h3>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Item Name</th>
                  <th>Idenfication Number</th>
                  <th>Laction</th>
                  <th>Name</th>
                  <th>Status</th>
                  <th>e-Mail</th>
                  <th>Phone</th>
                </tr>
              </thead>
              <tbody>
              <?php  foreach($found as $row) { ?>
                <tr>
                  <td><?=$row["device_name"]?></td>
                  <td><?=$row["number"]?></td>
                  <td><?=$row["location_name"]?></td>
                  <td><?=$row["name"]?></td>
                  <td><?=$row["status"]?></td>
                  <td><?=$row["email"]?></td>
                  <td><?=$row["phone"]?></td>
                </tr>
                 <?php  } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
