
 <div id="main-wrapper">
    <div id="main">
      <div id="main-inner">
        <div class="google-map-wrapper">
          <div id="google-map-directory"></div>
          <div class="container">
            <div class="google-map-filter col-xs-12 col-sm-4 col-md-3 pull-right">
            <?php echo form_open('welcome/search') ?> 
                <div class="form-group">
               	 	<?php echo form_dropdown('device_id', $device_list,$device_id,'id="device_id" class="form-control"');?>
                   	<?php echo form_error('device_id', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                  <input type="text" name="number" id="number" class="form-control" placeholder="NUMBER" value="<?=$number ?>" />
                   <?php echo form_error('number', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                	<?php echo form_dropdown('location_id', $location_list,$location_id,'id="location_id" class="form-control"');?>
                    <?php echo form_error('location_id', '<div class="error">', '</div>'); ?>
                </div>
                
                <div class="form-group">
                 	<input type="text" name="narration" id="narration" class="form-control" 
                    placeholder="NARRATION" value="<?=$narration ?>"/>
                   	<?php echo form_error('narration', '<div class="error">', '</div>'); ?>
                </div>             
                <div class="form-group">
                  <input type="submit" value="Search" class="btn btn-terciary btn-block" />
                </div>
                
              </form>
            </div>
            </div>
          </div>
        </div>
        <div class="secondary-images hidden-xs">
          <?php $this->load->view('device'); ?>
        </div>
      </div>
    </div>
  
    
 <script src="http://maps.google.com/maps/api/js?key=AIzaSyBH7c4Y0EwiCB3ugMkIYpOQ88Fyx3UaPMM&sensor=false" type="text/javascript"></script>
 <script type="text/javascript"> 
 

 
 
 <?php
		$loction=""; 
		foreach ($location_data as $row)
			$loction=$loction."['".$row["name"]."',".$row["lat"].",".$row["lng"]."],";
		if(strlen($loction)>0)
			$loction=substr($loction,0,strlen($loction)-1);
?>

	 
    var locations = [<?php echo $loction; ?>];

    var map = new google.maps.Map(document.getElementById('google-map-directory'), {
      zoom: 6,
      center: new google.maps.LatLng(23.8103, 90.4125),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
		  //alert(locations[i][0]);
		  //document.getElementById('location_id').value = "Dhaka";
		  //ele.value = locations[i][0];
		 var temp = locations[i][0];
		// alert(temp);
		 var selectObj = document.getElementById('location_id');
		 for (var t = 0; t < selectObj.options.length; t++) {
			if (selectObj.options[t].text== temp.trim()) {
				//selectObj.value = t;
				 selectObj.selectedIndex = t;
            	//return;
			}
		 }
		// alert(selectObj.options[selectObj.selectedIndex].text);
		//$(".chosen-single").html("<span>"+selectObj.options[selectObj.selectedIndex].text+"</span><div><b></b></div>");
		
		$("#location_id")
		.parent()

		.find(".chosen-single")
		.html("<span>"+selectObj.options[selectObj.selectedIndex].text+"</span><div><b></b></div>");
		}
      })(marker, i));
    }
	
	 //document.getElementById('device_id').value = "";
	 //document.getElementById('location_id').value = "";
	 
	 
	 
	 $(function() {
		
		$('#device_id').change(function(){
			$.get( "<?php echo $this->config->base_url(); ?>index.php/welcome/get_number?id="+ $(this).val(), function( data ) {
			  //$("#number").val("");
			  $("#number").attr("placeholder", data).placeholder();
			});
		});
		 
		 
		 
       $('.secondary-image > a').click(function(){
		   
		 var device_id = document.getElementById('device_id');
		 for (var t = 0; t < device_id.options.length; t++) {
			if (device_id.options[t].text== $(this).find(".image-max-width").attr("alt").trim()) {
				 device_id.selectedIndex = t;
			}
		 }
		
		$("#device_id")
		.parent()
		.find(".chosen-single")
		.html("<span>"+device_id.options[device_id.selectedIndex].text+"</span><div><b></b></div>");
		
		$('#device_id').change();
		return false;
		});
		
		
		$(window).on("load scroll resize",function(e){
			if ($(window).width() < 768) {
				$("#google-map-directory").hide();
			}
			else{
				$("#google-map-directory").show();
			}
		});
		
		
     }); 
	 
  </script>
  

 