
<script src="http://malsup.github.com/jquery.form.js"></script> 
<script type="text/javascript">
	$(function() {
	
		$('#device_id').change(function(){
			$.get( "<?php echo $this->config->base_url("welcome/get_number"); ?>?id="+ $(this).val(), function( data ) {
			  $("#number").attr("placeholder", data).placeholder();
			});
		});
		
		
		
		$('#image_file').change(function () {
			var frm=$('#frm_keep');
			frm.attr('action',"<?php echo $this->config->base_url("index.php/welcome/set_file")."?keep_id=".$keep_id; ?>");
		  	//frm.submit();
			frm.ajaxForm({
    			success: function (data) {
					var json = $.parseJSON(data);
					$('#image_display').append('<img height="100px" src='+data+' />');
				},
				error: function( jqXhr ) {
        			if( jqXhr.status == 400 ) { 
            			var json = $.parseJSON(jqXhr.responseText );
						alert(json.message);
        			}
    			}
			}).submit();
    	});
	

	});
</script>
	

<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
        
         <div class="col-xs-12 col-sm-12 col-md-12"  style="padding-top:10px" >  
          <h3>Keep the item </h3>
          </div>
          
          <div class="col-xs-12 col-sm-6 col-md-6" style="background-color:#fff;padding-top:10px;" >
          
               <div class="form-group">
                <div class="col-xs-12 col-sm-12">
                <?php echo form_open_multipart('welcome/keep_save',array('id' => 'frm_keep')) ?>
               		<input type="file" name="image_file" id="image_file"  />
                 </form> 
               </div>
               
              <div class="col-xs-12 col-sm-12" id="image_display" style="height:180px" >
              <?php 
			  	foreach($image_list as $row)
			  	{
					echo '<img height="100px" src="'.$row["image_url"].'" />';
				}
			   ?>
              </div>
              </div>
            </div>
             
             
          <div class="col-xs-12 col-sm-6 col-md-6"  style="background-color:#666;padding-top:10px;" > 
           <?php echo form_open('welcome/keep_save',array('id' => 'frm_keep_save')) ?>
              <div class="form-group">
               	 	<?php echo form_dropdown('device_id', $device_list,$device_id,'id="device_id" class="form-control"');?>
                   	<?php echo form_error('device_id', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                  <input type="text" name="number" id="number" class="form-control" placeholder="NUMBER" value="<?=$number ?>" />
                   <?php echo form_error('number', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                	<?php echo form_dropdown('location_id', $location_list,$location_id,'id="location_id" class="form-control"');?>
                    <?php echo form_error('location_id', '<div class="error">', '</div>'); ?>
                </div>
                
                <div class="form-group">
                 	<input type="text" name="narration" id="narration" class="form-control" 
                    placeholder="NARRATION" value="<?=$narration ?>"/>
                   	<?php echo form_error('narration', '<div class="error">', '</div>'); ?>
                </div> 
              <div class="form-group">
                <input type="text" name="email" id="email" class="form-control" placeholder="e-Mail" value="<?=$email ?>" />
                 <?php echo form_error('email', '<div class="error">', '</div>'); ?>
              </div>
               <div class="form-group">
                <input type="text" name="name" id="name" class="form-control" placeholder="Your Name" value="<?=$name ?>" />
                 <?php echo form_error('name', '<div class="error">', '</div>'); ?>
              </div>
               <div class="form-group">
                <input type="date" name="lost_found_date" id="lost_found_date" class="form-control" placeholder="Lost/Found Date" value="<?=$lost_found_date ?>" />
                 <?php echo form_error('lost_found_date', '<div class="error">', '</div>'); ?>
              </div>
               <div class="form-group">
                 <select name="status" id="status" class="form-control" style="display: none;">
                    <option value="lost" <?php if($status!="found") { ?> selected="selected"  <?php } ?>
                    >Lost</option>
                    <option value="found" <?php if($status=="found") { ?> selected="selected"  <?php } ?> 
                    >Found</option>
                  </select>
              </div>
              <div class="form-group">
                <input type="text" name="phone" id="phone" class="form-control" placeholder="Lost/Found Date" value="<?=$phone ?>" />
                 <?php echo form_error('phone', '<div class="error">', '</div>'); ?>
              </div>
              <div class="form-group">
                   <h4><?php if(isset($error)) echo '<div class="error">'.$error.'</div>'; ?></h4>
               </div>
               <div class="form-group">
                  <input type="hidden" name="keep_id" id="keep_id" value="<?=$keep_id?>" >
                  <input type="submit" value="Keep" class="btn btn-primary btn-block" />
                </div>
              </form> 
          </div>
          
         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

