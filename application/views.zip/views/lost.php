
<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="col-xs-12 col-sm-4 col-md-3"  style="background-color:#666;top:20px;padding-top:10px;" >  
              <div class="form-group">
			  <?php echo form_dropdown('device_id', $device_list,$device_id,'id="device_id"  class="form-control" readonly');?>
              </div>
              <div class="form-group">
                <input type="text" name="number" id="number" class="form-control"  value="<?=$number ?>" >
             </div>
              <div class="form-group"> <?php echo form_dropdown('location_id', $location_list,$location_id,'id="location_id" class="form-control" readonly');?> </div>
              <div class="form-group">
                <input type="text" name="name" id="name" class="form-control"  value="<?=$name ?>" >
              </div>
              <div class="form-group">
                <input type="text" name="email" id="email" class="form-control" readonly value="<?=$email ?>" >
              </div>
          </div>
          <div class="col-xs-12 col-sm-7 col-md-8 pull-right" style="background-color:#fff;top:20px;padding-top:10px" >
            <h3 style="color:#F00" >Sorry! we have not found the item. <br/> Could you can save it as lost? </h3>
               <?php echo form_open('welcome/pre_published') ?>
               <input type="hidden" name="id" id="id" value="<?=$id?>" > 
               <div class="form-group">
               <div class="row col-xs-12 col-sm-6 col-md-6" >
                    <div class="col-xs-6 col-sm-6">
                       <input type="submit" value="Yes" class="btn btn-terciary btn-block">
                    </div>
                    <div class="col-xs-6 col-sm-6">
                       <a href="<?php echo $this->config->base_url(); ?>" class="btn btn-terciary btn-block">No</a>
                    </div>
                 </div>
              </div>
              </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

