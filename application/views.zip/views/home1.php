
<div id="main-wrapper">
    <div id="main" >
      <div id="main-inner">
        <div class="google-map-wrapper">
         <div class="container">
          <div id="google-map-directory">
          </div>
          </div>
          <div class="container">
            <div class="google-map-filter col-xs-12 col-sm-4 col-md-3 pull-right">
               <?php echo form_open('welcome/lost') ?>
               
                <div class="form-group">
                  <select name="deviec_name" data-placeholder="Item" class="form-control">
                    <option value="#">Item</option>
                    <option selected="selected" value="#">Mobile</option>
                    <option value="#">Money Bag</option>
                    <option value="#">Certificate</option>
                    <option value="#">Tab</option>
                    <option value="#">Camera</option>
                    <option value="#">Passport</option>
                    <option value="#">N ID Card</option>
                    <option value="#">Bank Card</option>
                    <option value="#">Laptop</option>
                  </select>
                   <?php echo form_error('deviec_name', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                  <input type="text" name="number" class="form-control" placeholder="IME NUMBER" value="<?=$number ?>" >
                   <?php echo form_error('number', '<div class="error">', '</div>'); ?>
                </div>
                <div class="form-group">
                  <select id="ddl_location" name="ddl_location" data-placeholder="Location" class="form-control">
                    <option value="Location">Location</option>
                    <option value="Dhaka">Dhaka</option>
                    <option value="Chittagong">Chittagong</option>
                    <option value="Barisal">Barisal</option>
                    <option value="Khulan">Khulan</option>
                    <option value="Comilla">Comilla</option>
                    <option value="Rangpur">Rangpur</option>
                  </select>
                </div>
                <!-- /.form-group -->
                
                <div class="form-group">
                  <select name="" data-placeholder="Select City" class="form-control">
                    <option value="#">Select City</option>
                    <option value="#">Berlin</option>
                    <option value="#">Canberra</option>
                    <option value="#">London</option>
                    <option value="#">New York</option>
                    <option value="#">Paris</option>
                    <option value="#">Prague</option>
                  </select>
                </div>
                <div class="form-group">
                  <select name="" data-placeholder="Select Business Type" class="form-control">
                    <option value="#">Select Business Type</option>
                    <option value="#">Autoservice</option>
                    <option value="#">Bank</option>
                    <option value="#">Bar</option>
                    <option value="#">Castle</option>
                    <option value="#">Hospital</option>
                    <option value="#">Museum</option>
                    <option value="#">Restaurant</option>
                  </select>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-xs-6 col-sm-6">
                      <input type="text" class="form-control" placeholder="Price From">
                    </div>
                    <div class="col-xs-6 col-sm-6">
                      <input type="text" class="form-control" placeholder="Price To">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <input type="submit" value="Search" class="btn btn-terciary btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="secondary-images hidden-xs">
          <div class="row">
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/mobile.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/moneybag.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/certificate.png" alt="camera" class="image-max-width"> <span></span> </a> </div>
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/tab.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/card.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/laptop.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/passport.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/camera.png" alt="camera" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/nid.png" alt="" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/sim.png" alt="nid" class="image-max-width"> <span></span> </a> </div>
            <!-- /.secondary-image -->
            
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/book.png" alt="book" class="image-max-width"> <span></span> </a> </div>
            <div class="secondary-image col-sm-1"> <a href="#"> <img src="images/certificate.png" alt="" class="image-max-width"> <span></span> </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
<main class="mdl-layout__content mdl-color--grey-400">
  <div class="mdl-grid">
      <div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-desktop" >
         <?php echo form_open('welcome/lost') ?>
          <div class="mdl-card" >
            <div class="mdl-card__title  mdl-card--border">
              <h2 class="mdl-card__title-text" >I LOST</h2>
            </div>      
            <div class="mdl-card__supporting-text">
              <div class="mdl-textfield mdl-js-textfield" >
                <input class="mdl-textfield__input" id="deviec_name" name="deviec_name" type="text" value="<?=$deviec_name ?>" />
                <label class="mdl-textfield__label" for="deviec_name">MOBILE</label>
                 <?php echo form_error('deviec_name', '<div class="error">', '</div>'); ?>
              </div>
              <div class="mdl-textfield mdl-js-textfield" >
                <input class="mdl-textfield__input" id="number" name="number" type="text"  value="<?=$number ?>" />
                <label class="mdl-textfield__label" for="number">IME NUMBER</label>
                 <?php echo form_error('number', '<div class="error">', '</div>'); ?>
              </div>
              <div class="mdl-textfield mdl-js-textfield" >
                <input class="mdl-textfield__input" id="name" name="name" type="text" value="<?=$name ?>" />
                <label class="mdl-textfield__label" for="name">NAME</label>
                 <?php echo form_error('name', '<div class="error">', '</div>'); ?>
              </div>
              <div class="mdl-textfield mdl-js-textfield" >
                <input class="mdl-textfield__input" id="email" name="email" type="text" value="<?=$email ?>" />
                <label class="mdl-textfield__label" for="email">EMAIL/PHONE</label>
                 <?php echo form_error('email', '<div class="error">', '</div>'); ?>
              </div>
            </div>
            <div class="mdl-card__actions mdl-card--border">
              <button class="mdl-button mdl-button__icon mdl-js-button mdl-js-ripple-effect" > 
              <i class="material-icons">save</i> SAVE </button>
            </div>
          </div>
        </form>
      </div>
  </div>
</main>
