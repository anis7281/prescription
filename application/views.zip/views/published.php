
<script src="http://malsup.github.com/jquery.form.js"></script> 
<script type="text/javascript">
	$(function() {
		$('#image_file').change(function () {
			var frm=$('#frm_published');
			frm.attr('action',"<?php echo $this->config->base_url("index.php/welcome/set_file")."?id=".$id; ?>");
		  	//frm.submit();
			frm.ajaxForm({
    			success: function (data) {
					var json = $.parseJSON(data);
					$('#image_display').append('<img height="100px" src='+data+' />');
				},
				error: function( jqXhr ) {
        			if( jqXhr.status == 400 ) { 
            			var json = $.parseJSON(jqXhr.responseText );
						alert(json.message);
        			}
    			}
			}).submit();
			//return false;
    	});
	});
</script>
	

<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="col-xs-12 col-sm-4 col-md-3"  style="background-color:#666;top:20px;padding-top:10px;" >  
              <div class="form-group">
               <input type="text" name="number" id="number" class="form-control" readonly value="<?=$device_name ?>" > 
              </div>
              <div class="form-group">
                <input type="text" name="number" id="number" class="form-control" readonly value="<?=$number ?>" >
             </div>
              <div class="form-group">
              <input type="text" name="number" id="number" class="form-control" readonly value="<?=$location_name ?>" > 
               </div>
              <div class="form-group">
                <input type="text" name="name" id="name" class="form-control" readonly value="<?=$name ?>" >
              </div>
              <div class="form-group">
                <input type="text" name="email" id="email" class="form-control" readonly value="<?=$email ?>" >
              </div>
          </div>
          <div class="col-xs-12 col-sm-7 col-md-8 pull-right" style="background-color:#fff;top:20px;padding-top:10px" >
            <h3>Published the item </h3>
               <div class="form-group">
                <div class="col-xs-12 col-sm-12">
                 <?php echo form_open_multipart('welcome/set_file',array('id' => 'frm_published')) ?>
               		<input type="file" name="image_file" id="image_file"  />
                 </form> 
               </div>
               <div class="col-xs-12 col-sm-12" id="image_display">
               </div>
              </div>
             
               <div class="form-group">
              <?php echo form_open('welcome/published',array('id' => 'frm_published')) ?>
               	<input type="hidden" name="id" id="id" value="<?=$id?>" >
                    <div class="col-xs-12 col-sm-8">
                      <div class="checkbox">
                      <label>
                      <input type="checkbox" name="status" id="status" checked="checked"  value="Published">Published
                      </label></div>
                    </div>
                    <div class="col-xs-12 col-sm-4">
                     <input type="submit" value="Published" class="btn btn-terciary btn-block">
                    </div>
                 </form>
              </div>
          
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

