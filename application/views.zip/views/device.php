
          <div class="row">
          <?php foreach ($device_data as $row){ ?>
            <div class="secondary-image col-sm-1"> 
            <a href="#" >
            <img src="<?php echo $this->config->base_url().$row["url"]; ?>" alt="<?=$row["name"]?>" class="image-max-width"> <span></span> 
            </a> 
            </div>
            <?php } ?>
           
          </div>
          
  
