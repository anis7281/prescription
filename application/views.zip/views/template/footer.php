  <div id="footer-wrapper">
    <div id="footer">
      <div id="footer-inner">
        <div class="footer-bottom">
          <div class="container">
            <nav class="clearfix">
              <ul class="nav navbar-nav footer-nav">
                <li><a href="#">about us</a></li>
                <li><a href="#">contact us</a></li>
                <li><a href="#">our profile</a></li>
              </ul>
            </nav>
            <div class="copyright"> 
            <!-- Designed and develop by <a href="#">CreativeITpoint</a> / Assembled in <a href="#">Dhaka, Bangladesh</a>  -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
