<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
	<title>Lost and Found</title>
    <link href="<?php echo $this->config->base_url(); ?>favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
   	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Exo+2:200,300,400,500,600,600italic,700">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/chosen.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/ion.rangeSlider.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/ion.rangeSlider.skinNice.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/directory.css?20142206">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->base_url(); ?>css/bootstrap.vertical-tabs.min.css">
    
    <style>
	.error{
		color:#F00;
		background-color:#FFF;
		float:left;
		}
	</style>
    
	<script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.bxslider.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/chosen.jquery.min.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.isotope.min.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/ion.rangeSlider.min.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.flot.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/query.flot.canvas.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.flot.resize.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/jquery.flot.time.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/carousel.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/collapse.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/dropdown.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/tab.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/transition.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/graph.js"></script> 
    <script type="text/javascript" src="<?php echo $this->config->base_url(); ?>js/director.js"></script>


</head>
<body class="breadcrumb-white footer-top-dark">
<div id="page">
  <div id="header-wrapper">
    <div id="header">
      <div id="header-inner">
        <nav class="navbar navbar-default">
          <div class="header-secondary">
            <div class="container clearfix"> social link
              <ul class="languages">
                <li> <a href="https://www.facebook.com"><i class="fa fa-facebook-square color-gray-dark" title="facebook" ></i></a></li>
               	<li> <a href="https://www.twitter.com"><i class="fa fa-twitter-square color-gray-dark" title="twitter" ></i></a></li>
                <li> <a href="https://www.linkedin.com"><i class="fa fa-linkedin-square color-gray-dark" title="linkedin" ></i></a></li>
                <li> <a href="https://www.youtube.com"><i class="fa fa-youtube-square color-gray-dark" title="youtube" ></i></a></li>
              </ul>
              <ul class="header-submenu pull-right">
                <li><a href="#"><i class="fa fa-users color-gray-dark"></i> <span class="hidden-xs">Register</span></a></li>
                <li><a href="#"><i class="fa fa-sign-in color-gray-dark"></i> <span class="hidden-xs">Login</span></a></li>
                <li><a href="page-submit.html"><i class="fa fa-plus-square"></i> Submit</a></li>
              </ul>
            </div>
          </div>
          <div class="container">
            <div class="navbar-header"> <a class="navbar-brand" href="<?php echo $this->config->base_url(); ?>"> 
            <span class="logo-styled"> <span class="logo-title"><img src="<?php echo $this->config->base_url(); ?>images/logo1.png" alt="lost found"></span> <span class="logo-subtitle hidden-sm"></span> </span> </a> </div>
            <div class="collapse navbar-collapse" id="navbar-main">
              <ul class="nav navbar-nav navbar-right">
                <li class="menuparent"><a href="<?php echo $this->config->base_url(); ?>">Home</a></li>
                <li class="menuparent"><a href="<?php echo $this->config->base_url("welcome/lost"); ?>">Lost Item</a></li>
                <li class="menuparent"><a href="<?php echo $this->config->base_url("welcome/found"); ?>">Found Item</a></li>
                <li class="menuparent"><a href="<?php echo $this->config->base_url("welcome/keep"); ?>">Keep Item</a></li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
  