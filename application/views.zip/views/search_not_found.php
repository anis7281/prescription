<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="col-xs-12 col-sm-4 col-md-3" style="background-color:#666;top:20px;padding-top:10px" >
      
              <?php echo form_open('welcome/search') ?>
              <div class="form-group"> <?php echo form_dropdown('device_id', $device_list,$device_id,'id="device_id" class="form-control"');?> <?php echo form_error('device_id', '<div class="error">', '</div>'); ?> </div>
              <div class="form-group">
                <input type="text" name="number" id="number" class="form-control" placeholder="NUMBER" value="<?=$number ?>" >
                <?php echo form_error('number', '<div class="error">', '</div>'); ?> </div>
              <div class="form-group"> <?php echo form_dropdown('location_id', $location_list,$location_id,'id="location_id" class="form-control"');?> <?php echo form_error('location_id', '<div class="error">', '</div>'); ?> </div>
              <div class="form-group">
                <input type="text" name="narration" id="narration" class="form-control" placeholder="NARRATION" value="<?=$narration ?>" >
                <?php echo form_error('narration', '<div class="error">', '</div>'); ?> </div>
                
              <div class="form-group">
                <input type="submit" value="Search" class="btn btn-terciary btn-block">
              </div>
            </form>
          </div>
          <div class="col-xs-12 col-sm-7 col-md-8 pull-right" style="background-color:#fff;top:20px;padding-top:10px" >
           	<h3 style="color:#f00" >Item not found </h3>
           <h4> You can <a href="<?php echo $this->config->base_url("welcome/keep"); ?>" >keep item</a> in the server</h4>
            <?php if(count($found)>0) { ?>
            <h4>Related item list</h4>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Item Name</th>
                  <th>Idenfication Number</th>
                  <th>Founder Laction</th>
                  <th>Fonder Name</th>
                  <th>Fonder e-Mail</th>
                  <th>Narration</th>
                </tr>
              </thead>
              <tbody>
              <?php  foreach($found as $row) { ?>
                <tr>
                  <td><?=$row["device_name"]?></td>
                  <td><?=$row["number"]?></td>
                  <td><?=$row["location_name"]?></td>
                  <td><?=$row["name"]?></td>
                  <td><?=$row["email"]?></td>
                  <td><?=$row["narration"]?></td>
                </tr>
                 <?php  } ?>
              </tbody>
            </table>
             <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
