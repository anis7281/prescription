
<div id="main-wrapper">
  <div id="main">
    <div id="main-inner">
      <div class="google-map-wrapper">
        <div class="container">
          <div class="col-xs-12 col-sm-7 col-md-8" style="background-color:#fff;top:20px;padding-top:10px" >
            <h3>Your item has updated succefully </br> We are waiting e-mail verification for published </h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

