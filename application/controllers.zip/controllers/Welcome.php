<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->library('session');
	}
	
	public function index()
	{	
		$data['device_id']="";
		$data['location_id']="";
		$data['number']="";
		$data['narration']="";
		//$data['email']="";
		$data['device_data']= $this->get_device();
		$data['location_data']= $this->get_location();
		$data['device_list']= $this->get_device_dropdown($data['device_data']);
		$data['location_list']= $this->get_location_dropdown($data['location_data']);
		
		
		$this->load->view('template/header');
		$this->load->view('home',$data);
		$this->load->view('template/footer');
	}
	
	public function get_number()
	{	
		$id=$this->input->get("id");
		$sql="select number_caption from device_info where number_caption!='' and  id=".$id;
    	$result = $this->db->query($sql);
		$number="NUMBER";
		$result=$result->result_array();
    	if(count($result)>0)
		 $number = $result[0]["number_caption"];
    	echo $number;  
	}
	
	public function search()
	{	
		$this->load->library('form_validation');
		//$this->form_validation->set_rules('device_id', 'Device name', 'required');
		//$this->form_validation->set_rules('location_id', 'Location name', 'required');
		//$this->form_validation->set_rules('number', 'Number', 'required');
		$this->form_validation->set_rules('narration', 'Narration', 'required');
		
		$data['device_id']=$this->input->post("device_id");
		$data['location_id']=$this->input->post("location_id");
		$data['number']=$this->input->post("number");
		$data['narration']=$this->input->post("narration");
		
		$data['device_data']= $this->get_device();
		$data['location_data']= $this->get_location();
		$data['device_list']= $this->get_device_dropdown($data['device_data']);
		$data['location_list']= $this->get_location_dropdown($data['location_data']);

	
		if ($this->form_validation->run() == FALSE)
		{	
			$this->load->view('template/header');
			$this->load->view('home',$data);
			$this->load->view('template/footer');
			return;
		}
		
		$sql="verified='1' ";	
		
		if($data['device_id']!="0")
		  	$sql=$sql." and lfi.device_id=".$data['device_id'];
		
		if($data['location_id']!="0")
		  	$sql=$sql." and lfi.location_id=".$data['location_id'];
		
		if($data['number']!="")
			$sql=$sql." and lfi.number like '%".$data['number']."%'";
		
		if($data['narration']!="")
			$sql=$sql." and lfi.narration like '%".$data['narration']."%'";
		
		//if($data['name']!="")
		//$sql=$sql." or lfu.name like '%".$data['name']."%'";
		
		//if($data['email']!="")
		//$sql=$sql." and lfu.email like '".$data['email']."'";
		/*
		if($sql=="")
		{
			$this->load->view('template/header');
			$this->load->view('search_not_found',$data);
			$this->load->view('template/footer');
			return;
		}*/
		
		$sql="select di.name as device_name,lfi.number,lfu.name,lfu.email,li.name as location_name,
		lfi.status,lfi.narration
		from lost_found_info lfi 
		left join device_info di on lfi.device_id=di.id
		left join location_info li on lfi.location_id=li.id
		left join lost_found_user lfu on lfi.user_id=lfu.id
		where ".$sql;
		
		$query=$this->db->query($sql);
		$result=$query->result_array();
		
		if(count($result)>0)
		{
			$data["found"]=$result;
			$this->load->view('template/header');
			$this->load->view('search_found',$data);
			$this->load->view('template/footer');
		}		
		else
		{
			$sql="verified='1' ";
			if($data['number']!="")
			$sql=$sql." or lfi.number like '%".$data['number']."%'";
		
			if($data['narration']!="")
			$sql=$sql." or lfi.narration like '%".$data['narration']."%'";
				
			$sql="select di.name as device_name,lfi.number,lfu.name,lfu.email,li.name as location_name,
			lfi.status,lfi.narration
			from lost_found_info lfi 
			left join device_info di on lfi.device_id=di.id
			left join location_info li on lfi.location_id=li.id
			left join lost_found_user lfu on lfi.user_id=lfu.id
			where ".$sql;
			
			$query=$this->db->query($sql);
			$result=$query->result_array();

			$data["found"]=$result;
			$this->load->view('template/header');
			$this->load->view('search_not_found',$data);
			$this->load->view('template/footer');
				
			
			/*
			$this->db->trans_start();
			$data["user_id"]="1";
			$query=$this->db->query("select id from lost_found_user where email='".$data['email']."'");
			$result=$query->result_array();
			if(count($result)==0)
			{	
				$lost_found_user = array(
					'name' => $data['name'],
					'email'=> $data['email']
					);
				$this->db->insert('lost_found_user',$lost_found_user);
				$data["user_id"]=$this->db->insert_id();
			}
			else
			{
				$data["user_id"]=$result[0]["id"];
			}
			
			$lost_found_info = array(
				'user_id' => $data["user_id"],
				'device_id' => $data['device_id'],
				'location_id'=> $data['location_id'],
				'number' => $data['number']
                );
								
			$this->db->insert('lost_found_info',$lost_found_info);
			$data["id"]=$this->db->insert_id();
			$this->db->trans_complete(); 
						
			$this->load->view('template/header');
			$this->load->view('lost',$data);
			$this->load->view('template/footer');
			*/
		}
	   
	}
	
	public function keep()
	{	
		$data['keep_id']=uniqid();
		$data['device_id']="";
		$data['location_id']="";
		$data['number']="";
		$data['narration']="";
		$data['email']="";
		$data['status']="";
		$data['name']="";
		$data['phone']="";
		$data['lost_found_date']="";
		$data['device_list']= $this->get_device_dropdown($this->get_device());
		$data['location_list']= $this->get_location_dropdown($this->get_location());
		$data['image_list']= $this->get_keep_images($data['keep_id']);
		
		$this->load->view('template/header');
		$this->load->view('keep',$data);
		$this->load->view('template/footer');
		$newdata = array('keep_id' => $data['keep_id']);
		$this->session->set_userdata($newdata);	
	}
	
	public function keep_save()
	{	
		$this->load->library('form_validation');
		$this->form_validation->set_rules('device_id', 'Device name', 'required');
		$this->form_validation->set_rules('location_id', 'location name', 'required');
		$this->form_validation->set_rules('number', 'number', 'required');
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('status', 'status', 'required');
		$this->form_validation->set_rules('narration', 'narration', 'required');
		$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
		$this->form_validation->set_rules('lost_found_date', 'date', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		
		$data['keep_id']=$this->input->post("keep_id");
		$data['device_id']=$this->input->post("device_id");
		$data['location_id']=$this->input->post("location_id");
		$data['number']=$this->input->post("number");
		$data['narration']=$this->input->post("narration");
		$data['email']=$this->input->post("email");
		$data['status']=$this->input->post("status");
		$data['name']=$this->input->post("name");
		$data['phone']=$this->input->post("phone");
		$data['lost_found_date']=$this->input->post("lost_found_date");
		$data['device_list']= $this->get_device_dropdown($this->get_device());
		$data['location_list']= $this->get_location_dropdown($this->get_location());		
		$data['image_list']= $this->get_keep_images($data['keep_id']);
		
	
		
		if ($this->form_validation->run() == FALSE)
		{	
		
			$this->load->view('template/header');
			$this->load->view('keep',$data);
			$this->load->view('template/footer');
			return;
		}
		

		$data['id']= $this->session->userdata('keep_id');
		if($data['id']!=$data['keep_id'])
		{
			$data['error']="Late submitted";
			$this->load->view('template/header');
			$this->load->view('keep',$data);
			$this->load->view('template/footer');
			return;
		}
			
		
		$this->db->trans_start();
		$data["user_id"]="1";	
		$query=$this->db->query("select id from lost_found_user where email='".$data['email']."'");
		$result=$query->result_array();
		$lost_found_user = array(
				'name' => $data['name'],
				'email'=> $data['email'],
				'phone' => $data['phone']
				);
		if(count($result)==0)
		{	
			$this->db->insert('lost_found_user',$lost_found_user);
			$data["user_id"]=$this->db->insert_id();
			
		}
		else
		{
			$data["user_id"]=$result[0]["id"];
			$this->db->where('id',$data["user_id"]);
			$this->db->update('lost_found_user',$lost_found_user);
		}
			
		$lost_found_info = array(
			'user_id' => $data["user_id"],
			'device_id' => $data['device_id'],
			'location_id'=> $data['location_id'],
			'number' => $data['number'],
			'narration' => $data['narration'],
			'status' => $data['status'],
			'lost_found_date' => $data['lost_found_date'],
			'verification_id'=>$data['keep_id']
			);
								
		$this->db->insert('lost_found_info',$lost_found_info);
		$data["id"]=$this->db->insert_id();
		
		$this->load->library('email');
		$this->load->library('encrypt');
		$this->email
			->from('info@example.com', 'Lostfound')
			->to($data['email'])
			->subject('Lostfound verification')
			->message('Hi! '.$data['name'].',<br/> Please click flowing link to  
			 <a href="'.$this->config->base_url("index.php/welcome/verification")
			 .'"?keep_id="'.$this->encrypt->encode($keep_id).'" >verifiy</a> you request')
			->set_mailtype('html');
		$this->email->send();		
		$this->db->trans_complete(); 	
				
		$this->load->view('template/header');
		$this->load->view('verification');
		$this->load->view('template/footer');
			
	}
	
	public function verification()
	{
		$this->load->library('encryption');
		$keep_id = $this->encrypt->decode($this->input->get('keep_id'));
		$sql="select user_id from lost_found_info where verification_id='".$keep_id."'";
		$query=$this->db->query($sql);
		$result=$query->result_array();
		if(count($result)>0)
		{
			$user_id=$result[0]["user_id"];
			$this->db->where('user_id',$user_id);
			$this->db->update('lost_found_info',array('verified' => '1'));
			
			$sql="select di.name as device_name,lfi.number,lfu.name,lfu.email,li.name as location_name,
			lfi.status,lfi.narration,lfu.phone
			from lost_found_info lfi 
			left join device_info di on lfi.device_id=di.id
			left join location_info li on lfi.location_id=li.id
			inner join lost_found_user lfu on lfi.user_id=lfu.id
			where lfi.verified='1' and lfi.user_id=".$user_id;
			
			$query=$this->db->query($sql);
			$result=$query->result_array();
			$data["found"]=$result;
			$this->load->view('template/header');
			$this->load->view('verification_success',$data);
			$this->load->view('template/footer');
		
		}			
	
		$this->load->view('template/header');
		$this->load->view('verification_unsuccess');
		$this->load->view('template/footer');
	}
	
	public function pre_published()
	{	
		$id=$this->input->post("id");
		if(!isset($id))
		{
			 redirect($this->config->base_url("welcome/keep"));
		}
		
		$sql="select di.name as device_name,lfi.number,lfi.name,lfi.email,li.name as location_name
		from lost_found_info lfi 
		left join device_info di on lfi.device_id=di.id
		left join location_info li on lfi.location_id=li.id
		where lfi.id=".$id;
			
		$query=$this->db->query($sql);
		$result=$query->result_array();
		
		if(count($result)>0)
		{
			$data['id']=$id;				
			$data['device_name']=$result[0]["device_name"];
			$data['location_name']=$result[0]["location_name"];
			$data['number']=$result[0]["number"];
			$data['number']=$result[0]["number"];
			$data['name']=$result[0]["name"];
			$data['email']=$result[0]["email"];
			
			$this->load->view('template/header');
			$this->load->view('published',$data);
			$this->load->view('template/footer');
			return;
		}
		else
		{
		 	redirect($this->config->base_url("welcome/keep"));
		}
	}
	
	public function published()
	{	
		$id=$this->input->post("id");
		if(!isset($id))
		{
		 	redirect($this->config->base_url("welcome/keep"));
		}
		
		$status=$this->input->post("status");
		if(!isset($status)) $status="Private";
		
		$data=array('status'=>$status);
		$this->db->where('id',$id);
		$this->db->update('lost_found_info',$data); 
		
		$this->load->view('template/header');
		$this->load->view('published_success');
		$this->load->view('template/footer');
	}
	
	public function set_file()
	{	
		$id=$this->input->get("keep_id");
		$keep_id= $this->session->userdata('keep_id');
		if($id!=$keep_id)
		{
			$this->output->set_status_header('400'); 
			$this->data['status'] = "Upload Error";
			$this->data['message']="Late submitted  ".$id."   ".$keep_id ;
			echo json_encode($this->data);
			return;
		}
		
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		//$config['max_size'] = '100';
		//$config['max_width'] = '100';
		//$config['max_height'] = '100';
		$config['file_name'] = $id.'_image_file';
		$config['remove_spaces'] = TRUE;
		$this->load->library('upload', $config);
		
		if(!$this->upload->do_upload('image_file'))
		{
			$this->output->set_status_header('400'); 
			$this->data['status'] = "Upload Error";
			$this->data['message']=$this->upload->display_errors();
			echo json_encode($this->data);
			return;
		}
		
		$file = $this->upload->data();
		$image_url=$this->config->base_url("uploads")."/".$file["file_name"];
		$lost_found_images=array('keep_id'=>$id,'image_url'=>$image_url);
		$this->db->insert('lost_found_images',$lost_found_images);
		echo json_encode($image_url);
	}
	
	
	
	function get_device_dropdown($device_data)
	{
		$return[0] = "Item";
		foreach($device_data as $row){
			$return[$row['id']] = $row['name'];
    	}
    	return $return;
	}
	
	function get_location_dropdown($location_data)
	{
		$return[0] = "Location";
		foreach($location_data as $row){
			$return[$row['id']] = $row['name']; 	
    	}
    	return $return;
	}
	
	function get_location()
	{
		$sql="select id,name,lat,lng from location_info order by id";
		return $this->db->query($sql)->result_array();
	}
	
	function get_device()
	{
		$sql="select id,name,url from device_info order by id";
		return $this->db->query($sql)->result_array();
	}
	
	function get_keep_images($keep_id)
	{
		$sql="select id,keep_id,image_url from lost_found_images where keep_id='".$keep_id."'";
		return $this->db->query($sql)->result_array();
	}
}
